package com.kyuuze.tcortools;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(5, 8, 13);
    private final int PANEL = Color.rgb(13, 20, 30);
    private final int CYAN = Color.rgb(0, 217, 255);
    private final int WHITE = Color.rgb(235, 245, 255);
    private SharedPreferences prefs;
    private TextView status, speedValue, accelValue;
    private SeekBar speedBar, accelBar;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("tcor_mouse_profile", MODE_PRIVATE);
        buildUI();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(WHITE); t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(14), dp(18), dp(14));
        l.setBackgroundColor(PANEL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(7), 0, dp(7));
        l.setLayoutParams(p);
        return l;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(CYAN);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(22, 37, 52)));
        return b;
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(16));
        root.setBackgroundColor(BG);

        TextView title = label("TCOR TOOLS", 27);
        title.setTextColor(CYAN);
        root.addView(title);
        TextView subtitle = label("BY KYUUZE  •  MOUSE PROFILE", 12);
        subtitle.setTextColor(Color.LTGRAY);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.bottomMargin = dp(12);
        root.addView(subtitle, sp);

        LinearLayout card = column();
        card.addView(label("MOUSE CONFIG", 18));
        TextView info = new TextView(this);
        info.setText("Atur dan simpan profil lokal. Pengaturan ini tidak otomatis mengubah input Mobilador atau sensitivitas Free Fire.");
        info.setTextColor(Color.LTGRAY); info.setTextSize(13);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = dp(8);
        card.addView(info, ip);

        speedValue = label("", 14);
        speedBar = new SeekBar(this); speedBar.setMax(10);
        speedBar.setProgress(prefs.getInt("pointer_speed", 5));
        speedValue.setText("Pointer profile: " + speedBar.getProgress());
        speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { speedValue.setText("Pointer profile: " + p); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.topMargin = dp(10);
        card.addView(speedValue); card.addView(speedBar, bp);

        accelValue = label("", 14);
        accelBar = new SeekBar(this); accelBar.setMax(1);
        accelBar.setProgress(prefs.getInt("acceleration", 0));
        accelValue.setText("Acceleration profile: " + (accelBar.getProgress() == 1 ? "ON" : "OFF"));
        accelBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { accelValue.setText("Acceleration profile: " + (p == 1 ? "ON" : "OFF")); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        card.addView(accelValue); card.addView(accelBar, bp);
        root.addView(card);

        LinearLayout actions = column();
        actions.addView(label("PROFILE ACTIONS", 17));
        Button save = button("Simpan Profil");
        save.setOnClickListener(v -> {
            prefs.edit().putInt("pointer_speed", speedBar.getProgress())
                .putInt("acceleration", accelBar.getProgress()).apply();
            status.setText("Status: profil tersimpan di aplikasi");
            Toast.makeText(this, "Profil TCOR tersimpan", Toast.LENGTH_SHORT).show();
        });
        actions.addView(save);
        Button export = button("Ekspor Config .ini");
        export.setOnClickListener(v -> exportConfig());
        actions.addView(export);
        Button reset = button("Reset Profil");
        reset.setOnClickListener(v -> {
            speedBar.setProgress(5); accelBar.setProgress(0);
            prefs.edit().putInt("pointer_speed", 5).putInt("acceleration", 0).apply();
            status.setText("Status: profil direset");
        });
        actions.addView(reset);
        root.addView(actions);

        LinearLayout footer = column();
        status = new TextView(this);
        status.setText("Status: siap");
        status.setTextColor(CYAN); status.setTextSize(13);
        footer.addView(status);
        TextView note = new TextView(this);
        note.setText("Catatan: Android biasa tidak mengizinkan aplikasi mengubah perilaku mouse di aplikasi lain secara universal. Integrasi langsung perlu dukungan resmi Mobilador atau akses sistem yang sesuai.");
        note.setTextColor(Color.LTGRAY); note.setTextSize(12);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2); np.topMargin = dp(8);
        footer.addView(note, np);
        root.addView(footer);

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true); scroll.addView(root);
        setContentView(scroll);
    }

    private void exportConfig() {
        String data = "[DEVICE]\\nMODEL=Android\\nCONNECTION=USB_OTG\\n\\n[POINTER]\\nPOINTER_SPEED="
                + speedBar.getProgress() + "\\nACCELERATION=" + (accelBar.getProgress() == 1 ? 1 : 0)
                + "\\n\\n[PROFILE]\\nNAME=TCOR_DEFAULT\\n";
        File out = new File(getExternalFilesDir(null), "TCOR_Mouse_Config.ini");
        try (FileOutputStream fos = new FileOutputStream(out)) {
            fos.write(data.getBytes("UTF-8"));
            status.setText("Config diekspor: " + out.getAbsolutePath());
            Toast.makeText(this, "Config disimpan di folder Android/data aplikasi/files", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            status.setText("Gagal ekspor: " + e.getMessage());
        }
    }
}

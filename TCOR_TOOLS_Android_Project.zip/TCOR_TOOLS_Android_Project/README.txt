TCOR TOOLS — Android project
================================
Fitur:
- Profil pointer lokal (pengaturan profil di aplikasi)
- Simpan dan reset profil
- Ekspor file TCOR_Mouse_Config.ini
- UI hitam + biru neon

Penting:
Aplikasi ini belum mengubah input mouse di Mobilador/Free Fire secara langsung.
File .ini adalah format milik TCOR TOOLS, bukan format resmi Mobilador. Integrasi langsung
memerlukan dokumentasi/fitur yang memang didukung oleh Mobilador atau izin sistem yang sesuai.

Build:
1. Buka project ini di Android Studio.
2. Pastikan Android SDK 35 dan JDK 17 tersedia.
3. Jalankan Gradle sync.
4. Build > Build APK(s).
